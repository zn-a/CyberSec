#import "template.typ": *

#show: project.with(
  title: [
    #text(smallcaps("EE4410 Cyber Security of Power Grids\n"))
    #text("Assignment 1: URL Phishing and Malware Identification", size: 14pt)
  ],
  authors: (
    "Zubair Al-Zubi (5342007)",
  ),
  date: "May 21, 2025",
)

// make links blue
#show link: set text(fill: rgb(0, 0, 255))

// In this practicum, malicious URLs and malware files will be identified using the widely accessible tool _Virustotal_. Furthermore, passive reconnaissance will also be explored by employing the OSINT tool _Maltego_ to gather information discreetly without direct interaction.

// In this lab Assignment, we will explore the concepts of URL phishing and malware identification. We will analyze a dataset containing URLs and their corresponding labels to identify potential phishing attempts and malware threats. The dataset consists of various features extracted from the URLs, including their length, the presence of special characters, and other relevant attributes.

In this lab report, techniques for identifying malware and phishing attacks were explored. Public threat intelligence tools, such as VirusTotal and Cybercrime Tracker, were used to analyze file hashes and suspicious URLs. The aim was to demonstrate how malicious indicators can be detected and interpreted.

= Malware Identification Using VirusTotal

This section presents an analysis of file hashes and several malicious URLs using VirusTotal.

== File Hash Analysis

Five SHA256 hashes were analyzed using VirusTotal. Each hash yielded a detailed scan result showing the detection ratio and classification by multiple antivirus engines.

#figure(
  image("hashes.png"),
  caption: [Virustotal scan result of the five hash signatures]
)<hashes>

Of the five analyzed file hashes, three were clearly identified as malicious by VirusTotal, as shown in @hashes. Hence, three out of five samples were confirmed malware, while the other two were likely safe.

File signatures refer to the cryptographic hash of a file (in this case, SHA256), which acts as a unique fingerprint. These hashes allow antivirus tools to match the scanned file against known malicious signatures in threat databases. A consistent match across engines increases the confidence in a file's classification as malware.

== Malicious URLs

Three URLs were selected from the cybercrime-tracker.net platform and scanned using VirusTotal:

- `http://achillharpfestival.ie/wp-content/plugins/dbzytgojke/mail.php`
- `103.147.185.68/j/p30pq/login.php`
- `http://unwaveringmedia.com/wp-content/plugins/vsqjspmplq/remain.php
unwaveringmedia.com`

All three were identified as malicious by multiple security vendors and flagged for phishing, malware distribution, or suspicious behavior, as shown in @urls.

#figure(
  image("urls.png", width: 90%),
  caption: [Virustotal scan result of three malicious URLs]
)<urls>


The following common characteristics were observed among the malicious URLs:

- *Multiple detections*: VirusTotal showed consistent tagging of these URLs by trusted vendors (e.g., ArcSight , BitDefender, Fortinet), confirming their malicious nature.
- *Use of obscure paths*: All URLs contained plugin or folder names with randomized strings, e.g., `dbzytgojke`, `vsqjspmplq`, likely to evade signature-based detection.
- *Low community trust*: All URLs showed strongly negative community scores, indicating low user trust.
// - *Known malware infrastructure*: The hosting IPs and domains were previously used to distribute Mailers, Stealers, or Remote Access Trojans, as shown in .
- *404 response with hidden threats*: Despite returning status code 404, behavior and historical analysis revealed that these endpoints were actively used in campaigns.
// - *Phishing or credential harvesting*: Especially in the case of `login.php` under the IP address, the URL closely resembles typical phishing endpoints.

These results demonstrate how attackers frequently reuse compromised infrastructure, camouflage payload URLs, and take advantage of poorly secured or abandoned WordPress installations to carry out phishing and malware delivery.

The analysis demonstrates how phishing sites disguise themselves to appear legitimate while performing background activities such as credential harvesting or malware deployment.


// -----------

// The following common characteristics were observed among the malicious URLs:
// - **404 response with hidden threats**: Despite returning status code 404, analysis engines flagged underlying payload behavior or historical associations.
// - **Obfuscated file paths**: URLs contained random or nonstandard plugin names likely intended to evade detection.
// - **Low community trust**: All URLs showed strongly negative community scores, indicating low user trust and prior suspicious activity.

// The following common characteristics were observed among the malicious URLs:

// - **Suspicious domains**: The URLs used recently registered or obscure top-level domains (e.g., `.xyz`, `.click`, `.info`) which are frequently abused in phishing campaigns.
// - **Obfuscated scripts**: HTML and JavaScript content included multiple layers of obfuscation, often designed to evade detection by static analysis tools.
// - **Redirection behavior**: Many URLs used chained redirections, initially pointing to a benign-looking page and then redirecting users to phishing or malware-hosting sites.
// - **IP reputation**: The hosting IPs were associated with known malicious infrastructure, previously involved in spam, ransomware, or botnet activity.
// - **SSL certificates**: Either self-signed certificates or Let's Encrypt-issued certificates were used, with mismatched hostnames or short lifetimes.

// VirusTotal flagged these URLs based on both static indicators (domain age, structure) and dynamic behavior (live redirections, content injection). These traits indicate a high likelihood of phishing or malicious payload delivery.

// The analysis demonstrates how phishing sites disguise themselves to appear legitimate while performing background activities such as credential harvesting or malware deployment.




= Passive Reconnaissance Using Maltego

Maltego was used to perform Open-Source Intelligence (OSINT) on public web infrastructure and individuals. The objective was to simulate passive reconnaissance activities that an attacker might perform before launching a targeted cyber attack.

== Website Entity Investigation

A new Maltego graph was initialized using the "Website" entity type. The domain `www.tudelft.nl` was entered, and all available transforms were executed, as shown in . 


#figure(
  image("practicum-1-graph.png", width: 85%),
  caption: [Example Maltego website graph]
)


The results revealed detailed metadata, including:

- **Email addresses** associated with subdomains and services, such as `researchfunding@tudelft.nl`.
- **Subdomains and hosting services**
- **Third-party integrations** including Google Analytics, WhatsApp etc.
- **DNS information** such as IP addresses
// - **Certificate details** and HTTP/HTTPS versions of site endpoints

// This passive reconnaissance technique shows how a domain's digital footprint can be mapped non-intrusively. Such a graph enables adversaries to explore email targets, third-party services in use, or infrastructure relationships that could be used for phishing, impersonation, or vulnerability targeting.

// -----


// The results revealed detailed metadata, including:

// - Subdomains and DNS records (A, MX, NS)
// - Associated email addresses and certificate issuers
// - External hosting infrastructure and IP ranges
// - Third-party services and analytics tools embedded in the site

// This type of enumeration allows attackers to map a target’s digital footprint without direct interaction, thereby minimizing the risk of detection.

== Person Entity Investigation

It is also possible to perform a person search using Maltego by entering a name or alias and running available transforms. This reveals public data such as associated domains, usernames, and indexed online content,

// To simulate a targeted attack, the "Person" entity was used to query public information on a target name. Maltego retrieved data from social networks, domain registrations, and known data breaches. 

#figure(
  image("persons-graph-v2.jpg", width: 85%),
  caption: [Example Maltego person graph]
)

This technique can be used to identify potential impersonation, exposed infrastructure, or social activity linked to a target all without direct interaction.

// Results included:

// - Usernames reused across platforms
// - Email addresses linked to personal profiles
// - Public LinkedIn and Twitter accounts
// - Credential leak records from HaveIBeenPwned

// This demonstrates how passive methods can be used to construct a social engineering profile without accessing internal systems.

// #figure(
//   image("maltego-graph-example.png", width: 85%),
//   caption: [Example Maltego graph showing linked entities from a domain query]
// )<maltego-graph>

== Case Study: OSINT-Based Attack Scenario

In a simulated case, data extracted from the `www.tudelft.nl` domain showed email routing data pointing to third-party mail infrastructure. Public subdomains revealed backend services (`mail.tudelft.nl`, `vpn.tudelft.nl`) which, if unpatched, could be exploited further by attackers.

An adversary could:

1. Use DNS data to craft phishing emails spoofing institutional domains.
2. Search for exposed email credentials in known breach databases.
3. Launch password spraying attack or social engineering based on extracted employee names and positions.

This shows that OSINT is often the first step in reconnaissance, which enables attackers to launch spear phishing or credential-based attacks without breaching the perimeter.

== Countermeasures

To reduce exposure and defend against OSINT-based threats:

- Limit publicly visible metadata (e.g., hide unnecessary DNS records)
- Use WHOIS privacy and remove personal information from public registries
- Regularly monitor breach databases for leaked credentials
- Train employees to minimize exposure on public social media

// Maltego’s visual graphing makes it clear how easily structured relationships can be built from open data, reinforcing the need for privacy hygiene and infrastructure hardening.
